public class ProtectionHelmet extends ProtectionItem {
    public ProtectionHelmet() {
        super("Casque de protection", "Un casque basique.", 10, 20);
    }

    @Override
    public String asciiArt() {
        return "ASCII du Casque de protection";
    }

    @Override
    public void use(Player player) {
        System.out.println("Vous équipez le " + getName() + ", augmentant votre défense de " + getDefensePoints() + ".");
        player.increaseDefense(getDefensePoints());
    }
}
