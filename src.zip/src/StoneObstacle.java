class StoneObstacle extends Obstacle {
    public StoneObstacle(String name, int health) {
        super(name, health);
    }
}