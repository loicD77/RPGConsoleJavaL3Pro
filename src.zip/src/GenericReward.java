public class GenericReward extends Item {
    public GenericReward(String name, String description, int price) {
        super(name, description, price); // Appelle le constructeur de Item avec les paramètres nécessaires
    }

    @Override
    public void use(Player player) {
        System.out.println("Vous utilisez " + getName() + " : " + getDescription());
    }

    @Override
    public String asciiArt() {
        return "Art ASCII pour " + getName(); // Remplace par l'art ASCII de ton choix
    }
}
