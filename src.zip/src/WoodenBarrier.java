class WoodenBarrier extends Obstacle {
    public WoodenBarrier(String name, int health) {
        super(name, health);
    }
}