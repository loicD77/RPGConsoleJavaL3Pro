public class AntidotePotion extends Potion {
    public AntidotePotion(String name, String description, int healingAmount, int price) {
        super(name, description, healingAmount, price); // Appelle le constructeur de la classe parent avec tous les paramètres
        // D'autres initialisations si nécessaires
    }
}
